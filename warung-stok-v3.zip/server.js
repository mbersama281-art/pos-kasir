const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json({ limit: '8mb' }));

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const PASS = process.env.APP_PASSWORD || '';
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-haiku-5-5';
fs.mkdirSync(DATA_DIR, { recursive: true });

let db = { items: [], tx: [] };
try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) {}
if (!db.orders) db.orders = [];
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(db));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

// Proteksi sederhana pakai password (opsional, set APP_PASSWORD di Railway)
app.use('/api', (req, res, next) => {
  if (PASS && req.get('x-pass') !== PASS) return res.status(401).json({ error: 'Password salah' });
  next();
});

app.get('/api/items', (req, res) => res.json(db.items));

function clean(b){
  const n=v=>Math.max(0,+v||0), t=v=>String(v==null?'':v).trim();
  const o={nama:t(b.nama),satuan:t(b.satuan)||'pcs',isi:n(b.isi),beliDus:n(b.beliDus),beli:n(b.beli),jual:n(b.jual),jualDus:n(b.jualDus),stok:n(b.stok),min:n(b.min),kode:t(b.kode),kodeDus:t(b.kodeDus)};
  if(o.isi<=0){o.isi=0;o.beliDus=0;o.jualDus=0;o.kodeDus='';}
  else if(o.beliDus&&!o.beli)o.beli=o.beliDus/o.isi;
  return o;
}
function kodeError(o,id){
  if(o.kode&&o.kode===o.kodeDus) return 'Barcode satuan dan dus tidak boleh sama';
  const ks=[o.kode,o.kodeDus].filter(Boolean);
  const d=db.items.find(i=>i.id!==id&&ks.some(k=>i.kode===k||i.kodeDus===k));
  return d?'Barcode itu sudah dipakai '+d.nama:'';
}
app.post('/api/items',(req,res)=>{
  const o=clean(req.body);
  if(!o.nama) return res.status(400).json({error:'Nama wajib diisi'});
  const e=kodeError(o); if(e) return res.status(400).json({error:e});
  const item={id:uid(),...o}; db.items.push(item); save(); res.json(item);
});
app.put('/api/items/:id',(req,res)=>{
  const it=db.items.find(i=>i.id===req.params.id);
  if(!it) return res.status(404).json({error:'Tidak ada'});
  const o=clean({...it,...req.body});
  if(!o.nama) return res.status(400).json({error:'Nama wajib diisi'});
  const e=kodeError(o,it.id); if(e) return res.status(400).json({error:e});
  Object.assign(it,o); save(); res.json(it);
});
app.delete('/api/items/:id',(req,res)=>{
  db.items=db.items.filter(i=>i.id!==req.params.id); save(); res.json({ok:true});
});
function applyMove(type,it,unit,qty){
  if(unit==='dus'&&!(it.isi>0)) throw new Error(it.nama+': isi per dus belum diisi');
  const base=unit==='dus'?qty*it.isi:qty;
  if(type==='out'){
    if(base>it.stok) throw new Error('Stok '+it.nama+' kurang (sisa '+it.stok+' '+it.satuan+')');
    it.stok-=base;
  } else it.stok+=base;
  const jual=unit==='dus'?(it.jualDus||it.jual*it.isi)/it.isi:it.jual;
  db.tx.push({id:uid(),t:Date.now(),itemId:it.id,nama:it.nama,type,qty:base,jual,beli:it.beli});
}
app.post('/api/items/:id/move',(req,res)=>{
  const it=db.items.find(i=>i.id===req.params.id);
  if(!it) return res.status(404).json({error:'Tidak ada'});
  const qty=Math.abs(+req.body.qty||0);
  if(!qty) return res.status(400).json({error:'Jumlah tidak valid'});
  try{ applyMove(req.body.type==='in'?'in':'out',it,req.body.unit==='dus'?'dus':'satuan',qty); }
  catch(e){ return res.status(400).json({error:e.message}); }
  save(); res.json(it);
});
// Kasir scan: banyak barang sekaligus (satuan / dus)
app.post('/api/checkout',(req,res)=>{
  const type=req.body.type==='in'?'in':'out';
  const lines=(req.body.lines||[]).map(l=>({itemId:l.itemId,unit:l.unit==='dus'?'dus':'satuan',qty:+l.qty})).filter(l=>l.qty>0);
  if(!lines.length) return res.status(400).json({error:'Daftar kosong'});
  const need={};
  for(const l of lines){
    const it=db.items.find(i=>i.id===l.itemId);
    if(!it) return res.status(400).json({error:'Ada barang yang sudah dihapus'});
    if(l.unit==='dus'&&!(it.isi>0)) return res.status(400).json({error:it.nama+': isi per dus belum diisi'});
    need[it.id]=(need[it.id]||0)+(l.unit==='dus'?l.qty*it.isi:l.qty);
  }
  if(type==='out') for(const id in need){
    const it=db.items.find(i=>i.id===id);
    if(need[id]>it.stok) return res.status(400).json({error:'Stok '+it.nama+' kurang (sisa '+it.stok+' '+it.satuan+')'});
  }
  for(const l of lines) applyMove(type,db.items.find(i=>i.id===l.itemId),l.unit,l.qty);
  save(); res.json({ok:true});
});

app.get('/api/report', (req, res) => {
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const week = Date.now() - 7 * 864e5;
  const out = db.tx.filter(t => t.type === 'out');
  const sum = list => ({
    omzet: list.reduce((a, t) => a + t.jual * t.qty, 0),
    untung: list.reduce((a, t) => a + (t.jual - t.beli) * t.qty, 0),
    terjual: list.reduce((a, t) => a + t.qty, 0)
  });
  const top = {};
  out.filter(t => t.t >= week).forEach(t => top[t.nama] = (top[t.nama] || 0) + t.qty);
  res.json({
    hariIni: sum(out.filter(t => t.t >= start.getTime())),
    mingguIni: sum(out.filter(t => t.t >= week)),
    terlaris: Object.entries(top).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([nama, qty]) => ({ nama, qty })),
    nilaiStok: db.items.reduce((a, i) => a + i.beli * i.stok, 0)
  });
});

// Scan foto -> AI vision
app.post('/api/scan', async (req, res) => {
  try {
    const key = process.env.ANTHROPIC_API_KEY;
    if (!key) return res.status(500).json({ error: 'ANTHROPIC_API_KEY belum diset di Railway' });
    const data = String(req.body.image || '').replace(/^data:image\/\w+;base64,/, '');
    if (!data) return res.status(400).json({ error: 'Foto kosong' });

    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: MODEL, max_tokens: 300,
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data } },
          { type: 'text', text: 'Ini foto barang dagangan warung di Indonesia. Kenali produknya. ' +
            'Balas HANYA JSON tanpa teks lain: {"nama":"nama produk + merek + ukuran, contoh: Indomie Goreng 85g",' +
            '"satuan":"pcs/bungkus/botol/renteng/dus/kg/liter","barcode":"angka barcode jika terbaca, kalau tidak kosong",' +
            '"yakin":"tinggi/sedang/rendah"}. Jika bukan produk, isi nama dengan "".' }
        ] }]
      })
    });
    const j = await r.json();
    if (!r.ok) return res.status(500).json({ error: j.error?.message || 'Gagal memanggil AI' });
    const txt = (j.content || []).map(c => c.text || '').join('');
    const m = txt.match(/\{[\s\S]*\}/);
    if (!m) return res.status(500).json({ error: 'AI tidak memberi hasil yang bisa dibaca' });
    const out = JSON.parse(m[0]);
    const nama = String(out.nama || '').toLowerCase();
    const match = nama && db.items.find(i => {
      const n = i.nama.toLowerCase();
      return n === nama || n.includes(nama) || nama.includes(n);
    });
    res.json({ ...out, match: match || null });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});


// ---- Pesanan ----
app.get('/api/orders', (req, res) => res.json(db.orders.slice().reverse()));

app.post('/api/orders', (req, res) => {
  const b = req.body;
  if (!b.nama) return res.status(400).json({ error: 'Nama pemesan wajib diisi' });
  const lines = (b.lines || []).map(l => {
    const it = db.items.find(i => i.id === l.itemId);
    return it && +l.qty > 0 ? { itemId: it.id, nama: it.nama, satuan: it.satuan, qty: +l.qty } : null;
  }).filter(Boolean);
  if (!lines.length) return res.status(400).json({ error: 'Pilih minimal 1 barang' });
  const o = { id: uid(), t: Date.now(), nama: String(b.nama).trim(), catatan: b.catatan || '', lines, status: 'baru' };
  db.orders.push(o); save(); res.json(o);
});

app.post('/api/orders/:id/done', (req, res) => {
  const o = db.orders.find(x => x.id === req.params.id);
  if (!o) return res.status(404).json({ error: 'Pesanan tidak ada' });
  if (o.status === 'selesai') return res.status(400).json({ error: 'Sudah selesai' });
  for (const l of o.lines) {
    const it = db.items.find(i => i.id === l.itemId);
    if (!it) return res.status(400).json({ error: l.nama + ' sudah dihapus dari stok' });
    if (it.stok < l.qty) return res.status(400).json({ error: 'Stok ' + it.nama + ' kurang (sisa ' + it.stok + ')' });
  }
  for (const l of o.lines) {
    const it = db.items.find(i => i.id === l.itemId);
    it.stok -= l.qty;
    db.tx.push({ id: uid(), t: Date.now(), itemId: it.id, nama: it.nama, type: 'out', qty: l.qty, jual: it.jual, beli: it.beli });
  }
  o.status = 'selesai'; save(); res.json(o);
});

app.delete('/api/orders/:id', (req, res) => {
  db.orders = db.orders.filter(x => x.id !== req.params.id);
  save(); res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, 'public')));
app.listen(process.env.PORT || 3000, () => console.log('Warung Stok jalan'));
